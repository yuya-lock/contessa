package main

import "github.com/yuya-lock/contessa/api/routers"

func main() {
	routers.Init()
}
