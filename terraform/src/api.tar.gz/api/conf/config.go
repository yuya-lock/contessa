package conf

const (
	COCKTAILS_API_URL string = "https://cocktail-f.com/api/v1/cocktails"
	DBPORT            string = "3306"
	DBNAME            string = "zinnia_db"
)
